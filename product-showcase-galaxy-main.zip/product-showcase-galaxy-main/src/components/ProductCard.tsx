
import { Product } from "@/types";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Eye, Heart, ShoppingCart, Star } from "lucide-react";

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const { title, price, image, rating } = product;

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-lg h-full flex flex-col">
      <div className="relative pt-4 px-4">
        <div className="bg-gray-50 rounded-lg p-4 h-48 flex items-center justify-center overflow-hidden">
          <img
            src={image}
            alt={title}
            className="h-full object-contain mix-blend-multiply"
          />
        </div>
        <button className="absolute top-6 right-6 p-1.5 bg-white rounded-full shadow-sm hover:bg-gray-100 transition-colors">
          <Heart size={18} className="text-gray-600" />
        </button>
      </div>
      <CardContent className="flex-grow pt-4">
        <h3 className="font-medium text-sm mb-1 line-clamp-2 h-10" title={title}>
          {title}
        </h3>
        <div className="flex items-center mt-2">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                size={14}
                className={`${
                  i < Math.floor(rating.rate)
                    ? "text-yellow-400 fill-yellow-400"
                    : "text-gray-300"
                }`}
              />
            ))}
          </div>
          <span className="text-xs text-gray-500 ml-1">({rating.count})</span>
        </div>
        <div className="mt-2 text-primary font-semibold">${price.toFixed(2)}</div>
      </CardContent>
      <CardFooter className="pt-0 flex flex-col gap-2">
        <Button className="w-full bg-primary hover:bg-primary-dark" size="sm">
          <ShoppingCart size={16} className="mr-2" />
          Add to cart
        </Button>
        <Button variant="outline" size="sm" className="w-full">
          <Eye size={16} className="mr-2" />
          Quick view
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ProductCard;
