
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import FilterSidebar from "./FilterSidebar";
import { Filter } from "lucide-react";

interface MobileFilterDrawerProps {
  categories: string[];
  selectedCategories: string[];
  onCategoryChange: (category: string) => void;
  priceRange: [number, number];
  onPriceRangeChange: (range: [number, number]) => void;
}

const MobileFilterDrawer = ({
  categories,
  selectedCategories,
  onCategoryChange,
  priceRange,
  onPriceRangeChange,
}: MobileFilterDrawerProps) => {
  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className="md:hidden flex items-center"
        >
          <Filter size={16} className="mr-2" />
          Filters
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[300px] p-0">
        <FilterSidebar
          categories={categories}
          selectedCategories={selectedCategories}
          onCategoryChange={onCategoryChange}
          priceRange={priceRange}
          onPriceRangeChange={onPriceRangeChange}
          isMobile={true}
        />
      </SheetContent>
    </Sheet>
  );
};

export default MobileFilterDrawer;
