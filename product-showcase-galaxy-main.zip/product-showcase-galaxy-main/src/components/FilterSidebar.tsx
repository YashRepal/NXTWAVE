
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Filter } from "lucide-react";

interface FilterSidebarProps {
  categories: string[];
  selectedCategories: string[];
  onCategoryChange: (category: string) => void;
  priceRange: [number, number];
  onPriceRangeChange: (range: [number, number]) => void;
  isMobile?: boolean;
  onClose?: () => void;
}

const capitalizeFirstLetter = (string: string) => {
  return string.charAt(0).toUpperCase() + string.slice(1);
};

const FilterSidebar = ({
  categories,
  selectedCategories,
  onCategoryChange,
  priceRange,
  onPriceRangeChange,
  isMobile = false,
  onClose,
}: FilterSidebarProps) => {
  const [localPriceRange, setLocalPriceRange] = useState<[number, number]>(priceRange);

  const handlePriceRangeChange = (value: number[]) => {
    const newRange: [number, number] = [value[0], value[1]];
    setLocalPriceRange(newRange);
  };

  const handleApplyPriceRange = () => {
    onPriceRangeChange(localPriceRange);
  };

  const handleClearFilters = () => {
    onPriceRangeChange([0, 1000]);
    categories.forEach(category => {
      if (selectedCategories.includes(category)) {
        onCategoryChange(category);
      }
    });
  };

  return (
    <div className={`bg-white px-4 py-6 ${isMobile ? 'h-full overflow-auto' : 'h-auto'}`}>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold flex items-center">
          <Filter size={20} className="mr-2" /> Filters
        </h2>
        {isMobile && (
          <Button variant="ghost" size="sm" onClick={onClose}>
            Close
          </Button>
        )}
      </div>

      <Accordion type="single" collapsible defaultValue="categories">
        <AccordionItem value="categories">
          <AccordionTrigger className="text-sm font-medium">
            Categories
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {categories.map((category) => (
                <div key={category} className="flex items-center space-x-2">
                  <Checkbox
                    id={category}
                    checked={selectedCategories.includes(category)}
                    onCheckedChange={() => onCategoryChange(category)}
                  />
                  <label
                    htmlFor={category}
                    className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {capitalizeFirstLetter(category)}
                  </label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="price">
          <AccordionTrigger className="text-sm font-medium">
            Price Range
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <Slider
                defaultValue={[priceRange[0], priceRange[1]]}
                max={1000}
                step={10}
                value={[localPriceRange[0], localPriceRange[1]]}
                onValueChange={handlePriceRangeChange}
              />
              <div className="flex items-center justify-between">
                <span className="text-sm">${localPriceRange[0]}</span>
                <span className="text-sm">${localPriceRange[1]}</span>
              </div>
              <Button size="sm" variant="outline" onClick={handleApplyPriceRange} className="w-full">
                Apply
              </Button>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <div className="mt-6">
        <Button variant="outline" size="sm" onClick={handleClearFilters} className="w-full">
          Clear All Filters
        </Button>
      </div>
    </div>
  );
};

export default FilterSidebar;
